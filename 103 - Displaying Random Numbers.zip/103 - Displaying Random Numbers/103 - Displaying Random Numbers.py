from random import randrange

for i in range(3):
    print(randrange(100, 999, 5), end=" , ")
