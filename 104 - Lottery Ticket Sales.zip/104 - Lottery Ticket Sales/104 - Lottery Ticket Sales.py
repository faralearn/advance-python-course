from random import random, randrange, sample

# لیست برای ذخیره بلیط‌های لاتاری
lotteryList = []

# ایجاد 100 بلیط لاتاری با شماره‌های تصادفی
for i in range(100):
    # تولید یک عدد تصادفی 8 رقمی و افزودن به لیست بلیط‌ها
    lotteryList.append(randrange(1000000000, 9999999999, 2))

# انتخاب 2 برنده به‌صورت تصادفی از لیست بلیط‌ها
winners = sample(lotteryList, 2)

# نمایش برندگان
print("winners: ", winners)
